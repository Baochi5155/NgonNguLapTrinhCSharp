﻿using System;
using System.Windows.Forms;

namespace B1_1
{
    public partial class Cbo_Dantoc : Form
    {
        public Cbo_Dantoc()
        {
            InitializeComponent();
        }

        // Sự kiện click của button Load dữ liệu Combobox
        private void btn_loadDL_Click(object sender, EventArgs e)
        {
            string[] dt = { "Kinh", "Hoa", "K'Me", "H'Mong", "Khac" };
            cbo_dt.Items.Clear(); // Xóa dữ liệu cũ nếu bấm nạp lại
            foreach (string s in dt)
            {
                cbo_dt.Items.Add(s); 
            }
        }

        // Sự kiện click của button Hiển thị (Cách 1)
        private void btn_hienthi_Click(object sender, EventArgs e)
        {
            string s = "Dân tộc được chọn: "; 
            if (cbo_dt.SelectedIndex >= 0)
                lbl_kq.Text = s + cbo_dt.SelectedItem.ToString(); 
            else
                lbl_kq.Text = "Bạn chưa chọn dân tộc"; 
        }

        // Sự kiện SelectedIndexChanged của Combobox (Cách 2)
        private void cbo_dt_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbo_dt.SelectedItem != null)
            {
                MessageBox.Show("Dân tộc được chọn: " + cbo_dt.SelectedItem.ToString()); 
            }
        }
    }
}