﻿using System;
using System.Windows.Forms;

namespace B4_3
{
    public partial class frmDanhBa : Form
    {
        public frmDanhBa()
        {
            InitializeComponent();
        }

        // 1. Khi Form load: Tạo các Node gốc chứa ký tự từ A -> Z
        private void frmDanhBa_Load(object sender, EventArgs e)
        {
            trvDanhBa.Nodes.Clear();
            for (char c = 'A'; c <= 'Z'; c++)
            {
                // Thêm node với Key và Text đều là chữ cái tương ứng
                trvDanhBa.Nodes.Add(c.ToString(), c.ToString());
            }
        }

        // 2. Nút "Add": Thêm người mới vào node tương ứng với chữ cái đầu của tên
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();

            // Kiểm tra First Name không được để trống
            if (string.IsNullOrEmpty(firstName))
            {
                MessageBox.Show("Vui lòng nhập First Name!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFirstName.Focus();
                return;
            }

            // Lấy chữ cái đầu tiên của First Name để tìm node chữ cái
            string firstChar = firstName.Substring(0, 1).ToUpper();

            // Tìm node chữ cái tương ứng từ A -> Z
            TreeNode[] foundNodes = trvDanhBa.Nodes.Find(firstChar, false);

            if (foundNodes.Length > 0)
            {
                TreeNode targetNode = foundNodes[0];

                // Định dạng hiển thị: "First Name, Last Name" (ví dụ: Bình, Ngô Thanh)
                string displayName = string.IsNullOrEmpty(lastName) ? firstName : $"{firstName}, {lastName}";

                // Thêm danh bạ mới vào node chữ cái tương ứng
                TreeNode newContact = new TreeNode(displayName);
                targetNode.Nodes.Add(newContact);
                targetNode.Expand(); // Mở rộng node chữ cái

                // Xóa trắng ô nhập liệu
                txtFirstName.Clear();
                txtLastName.Clear();
                txtFirstName.Focus();
            }
            else
            {
                MessageBox.Show("Chữ cái đầu tiên phải thuộc từ A đến Z!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // 3. Nút "Exit": Đóng chương trình
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Xác nhận thoát ứng dụng
        private void frmDanhBa_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}