﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace B1_1
{
    public partial class frmUocSo : Form
    {
        public frmUocSo()
        {
            InitializeComponent();
        }

        // Hàm kiểm tra số nguyên tố
        private bool IsPrime(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }

        // 1. Nút Cập nhật: Thêm số vào ComboBox (có kiểm tra dữ liệu và trùng lặp)
        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu nhập là số nguyên dương 
            if (!int.TryParse(txtSo.Text.Trim(), out int val) || val <= 0)
            {
                MessageBox.Show("Vui lòng nhập một số nguyên dương hợp lệ!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSo.SelectAll();
                txtSo.Focus();
                return;
            }

            string item = val.ToString();

            // Kiểm tra số vừa nhập đã tồn tại trong ComboBox chưa  
            if (cboSo.Items.Contains(item))
            {
                MessageBox.Show("Số này đã tồn tại trong danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                cboSo.Items.Add(item);
                cboSo.SelectedItem = item; // Chọn ngay số vừa thêm
            }

            // Xóa dữ liệu textbox và đặt lại con trỏ
            txtSo.Clear();
            txtSo.Focus();
        }

        // 2. Sự kiện chọn số trong ComboBox -> Hiển thị danh sách ước số lên ListBox
        private void cboSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstUocSo.Items.Clear();

            if (cboSo.SelectedItem != null && int.TryParse(cboSo.SelectedItem.ToString(), out int n))
            {
                // Tìm các ước số của n
                for (int i = 1; i <= n; i++)
                {
                    if (n % i == 0)
                    {
                        lstUocSo.Items.Add(i);
                    }
                }
            }
        }

        // 3. Nút Tính "Tổng các ước số"
        private void btnTongUocSo_Click(object sender, EventArgs e)
        {
            if (lstUocSo.Items.Count == 0)
            {
                MessageBox.Show("Chưa có ước số nào trong danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int sum = 0;
            foreach (var item in lstUocSo.Items)
            {
                sum += Convert.ToInt32(item);
            }

            MessageBox.Show($"Tổng các ước số là: {sum}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // 4. Nút Tính "Số lượng các ước số chẵn"
        private void btnSoLuongUocSoChan_Click(object sender, EventArgs e)
        {
            if (lstUocSo.Items.Count == 0)
            {
                MessageBox.Show("Chưa có ước số nào trong danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int count = 0;
            foreach (var item in lstUocSo.Items)
            {
                int val = Convert.ToInt32(item);
                if (val % 2 == 0)
                {
                    count++;
                }
            }

            MessageBox.Show($"Số lượng các ước số chẵn là: {count}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // 5. Nút Tính "Số lượng các ước số nguyên tố"  
        private void btnSoLuongUocSoNguyenTo_Click(object sender, EventArgs e)
        {
            if (lstUocSo.Items.Count == 0)
            {
                MessageBox.Show("Chưa có ước số nào trong danh sách!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int count = 0;
            foreach (var item in lstUocSo.Items)
            {
                int val = Convert.ToInt32(item);
                if (IsPrime(val))
                {
                    count++;
                }
            }

            MessageBox.Show($"Số lượng các ước số nguyên tố là: {count}", "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // 6. Nút Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Xác nhận khi đóng Form
        private void frmUocSo_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát khỏi ứng dụng?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}