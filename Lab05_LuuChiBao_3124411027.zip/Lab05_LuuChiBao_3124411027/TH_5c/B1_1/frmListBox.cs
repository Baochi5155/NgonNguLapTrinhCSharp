﻿using System;
using System.Windows.Forms;

namespace B1_1
{
    public partial class frmListBox : Form
    {
        public frmListBox()
        {
            InitializeComponent();
        }

        // Khởi tạo danh sách mẫu khi nạp Form
        private void frmListBox_Load(object sender, EventArgs e)
        {
            lst_Trai.Items.Add("Cốc");
            lst_Trai.Items.Add("Ổi");
            lst_Trai.Items.Add("Xoài");
            lst_Trai.Items.Add("Me");
            lst_Trai.Items.Add("Bưởi");
            lst_Trai.Items.Add("Cam");
        }

        // Chuyển 1 phần tử đang chọn từ ListBox trái sang ListBox phải 
        private void btnQuaPhai_Click(object sender, EventArgs e)
        {
            if (lst_Trai.SelectedItem != null)
            {
                lst_Phai.Items.Add(lst_Trai.SelectedItem);
                lst_Trai.Items.Remove(lst_Trai.SelectedItem);
            }
        }

        // Chuyển tất cả phần tử từ ListBox trái sang ListBox phải 
        private void btnQuaPhaiAll_Click(object sender, EventArgs e)
        {
            lst_Phai.Items.AddRange(lst_Trai.Items);
            lst_Trai.Items.Clear();
        }

        // Chuyển 1 phần tử đang chọn từ ListBox phải sang ListBox trái 
        private void btnQuaTrai_Click(object sender, EventArgs e)
        {
            if (lst_Phai.SelectedItem != null)
            {
                lst_Trai.Items.Add(lst_Phai.SelectedItem);
                lst_Phai.Items.Remove(lst_Phai.SelectedItem);
            }
        }

        // Chuyển tất cả phần tử từ ListBox phải sang ListBox trái
        private void btnQuaTraiAll_Click(object sender, EventArgs e)
        {
            lst_Trai.Items.AddRange(lst_Phai.Items);
            lst_Phai.Items.Clear();
        }

        // Chuyển tùy ý: Chuyển các item được chọn từ ListBox trái sang ListBox 
        private void btnChuyenTuyY_Click(object sender, EventArgs e)
        {
            lst_Trai.SelectionMode = SelectionMode.MultiExtended; // Cho phép chọn nhiều item
            while (lst_Trai.SelectedItems.Count > 0)
            {
                lst_Phai.Items.Add(lst_Trai.SelectedItems[0]);
                lst_Trai.Items.Remove(lst_Trai.SelectedItems[0]);
            }
        }

        // Xác nhận khi người dùng đóng Form 
        private void frmListBox_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn đóng Form không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
            {
                e.Cancel = true; // Hủy thao tác đóng Form
            }
        }
    }
}